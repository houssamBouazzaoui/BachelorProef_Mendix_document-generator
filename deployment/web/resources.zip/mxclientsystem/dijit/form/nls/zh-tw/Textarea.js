//>>built
define("dijit/form/nls/zh-tw/Textarea",({iframeEditTitle:"編輯區",iframeFocusTitle:"編輯區框"}));

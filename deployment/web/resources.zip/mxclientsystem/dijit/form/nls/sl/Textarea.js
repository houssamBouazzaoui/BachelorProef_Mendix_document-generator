//>>built
define("dijit/form/nls/sl/Textarea",({iframeEditTitle:"urejevalno področje",iframeFocusTitle:"okvir urejevalnega področja"}));

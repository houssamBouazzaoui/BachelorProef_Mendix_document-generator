//>>built
define("dijit/nls/fi/loading",({loadingState:"Lataus on meneillään...",errorState:"On ilmennyt virhe."}));
